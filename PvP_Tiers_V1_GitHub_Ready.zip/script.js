const categories = ["Crystal","Sword","Mace","Axe","UHC","SMP","NethPot","DiaPot"];
const tiers = ["Grandmaster","HT1","HT2","HT3","HT4","LT1","LT2","LT3","LT4","Dwarriors"];

const demoPlayers = [
  {name:"FlameFrags",category:"Crystal",tier:"Grandmaster"},
  {name:"Marloww",category:"Sword",tier:"HT1"},
  {name:"Unstable",category:"Mace",tier:"HT2"},
  {name:"CaejjudeMC",category:"SMP",tier:"LT1"},
  {name:"PvPPlayer",category:"UHC",tier:"Dwarriors"}
];

const $ = id => document.getElementById(id);
const avatar = name => `https://skinrender.dev/render/${encodeURIComponent(name)}/face?size=128`;

function fillCategories(){
  $("categoryFilter").innerHTML = `<option value="All">All categories</option>` +
    categories.map(c => `<option value="${c}">${c}</option>`).join("");
}

function tierShort(tier){
  return tier === "Grandmaster" ? "GM" : tier === "Dwarriors" ? "DW" : tier;
}

function renderLeaderboard(){
  const filter = $("categoryFilter").value;
  const list = demoPlayers.filter(p => filter === "All" || p.category === filter);
  $("leaderboardList").innerHTML = list.map((p,i) => `
    <article class="player-row">
      <div class="position">${i+1}</div>
      <img src="${avatar(p.name)}" alt="${p.name} Minecraft skin"
           onerror="this.style.opacity='.35'">
      <div class="player-main">
        <div class="player-name">${escapeHTML(p.name)}</div>
        <div class="player-meta">${p.category} PvP • Demo ranking</div>
      </div>
      <div class="rank-pill">${tierShort(p.tier)}</div>
    </article>
  `).join("") || `<p>No players in this category yet.</p>`;
}

function showProfile(name){
  const normalized = name.trim();
  if(!/^[A-Za-z0-9_]{3,16}$/.test(normalized)){
    $("searchMessage").textContent = "Use a valid Java username (3–16 letters, numbers or underscore).";
    return;
  }

  $("searchMessage").textContent = "Loading skin preview...";
  $("profileSection").classList.remove("hidden");
  $("profileCard").innerHTML = `
    <div class="profile-card">
      <img class="skin" src="${avatar(normalized)}" alt="${normalized} skin"
           onerror="this.alt='Skin unavailable'">
      <div>
        <span class="eyebrow">PLAYER PROFILE</span>
        <div class="profile-name">${escapeHTML(normalized)}</div>
        <div class="profile-sub">Minecraft Java username • Skin preview</div>
        <div class="category-grid">
          ${categories.map(c => `
            <div class="category">
              <small>${c}</small>
              <b class="tier dw">DW</b>
            </div>
          `).join("")}
        </div>
      </div>
    </div>
  `;
  $("searchMessage").textContent = "Skin preview loaded when the public skin service responds.";
  $("profileSection").scrollIntoView({behavior:"smooth",block:"start"});
}

function escapeHTML(value){
  return value.replace(/[&<>"']/g, char => ({
    "&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"
  }[char]));
}

$("searchForm").addEventListener("submit", event => {
  event.preventDefault();
  showProfile($("usernameInput").value);
});

$("categoryFilter").addEventListener("change", renderLeaderboard);
fillCategories();
renderLeaderboard();
